Robinhood API Library
=======================

This project aims to create simple to use functions to interact with the
Robinhood API.
